# spextract
Software designed to parse raw measurement data

