def main() -> int:
    print("Hello World")
    return 1
